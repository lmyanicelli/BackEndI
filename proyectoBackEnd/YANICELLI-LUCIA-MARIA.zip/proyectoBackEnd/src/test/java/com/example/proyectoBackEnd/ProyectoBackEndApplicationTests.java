package com.example.proyectoBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
