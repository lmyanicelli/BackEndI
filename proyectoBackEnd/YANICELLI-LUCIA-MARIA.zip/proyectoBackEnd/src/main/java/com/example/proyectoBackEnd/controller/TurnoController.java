package com.example.proyectoBackEnd.controller;

import com.example.proyectoBackEnd.model.Turno;
import com.example.proyectoBackEnd.service.OdontologoService;
import com.example.proyectoBackEnd.service.PacienteService;
import com.example.proyectoBackEnd.service.TurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//REVISAR
@RestController
@RequestMapping("/turnos")
public class TurnoController {

    @Autowired
    TurnoService service;

    @Autowired
    PacienteService pacienteService;

    @Autowired
    OdontologoService odontologoService;

    @PostMapping("/registrar")
    public ResponseEntity<Turno> crear(@RequestBody Turno turno){
        ResponseEntity<Turno> response;
        if (pacienteService.buscar(turno.getPaciente().getId())!= null && odontologoService.buscar(turno.getOdontologo().getId()) != null)
            response = ResponseEntity.ok(service.guardar(turno));

        else
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        return response;
    }

    @GetMapping()
    public ResponseEntity<List<Turno>> consultarTodos(){
        return ResponseEntity.ok(service.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Turno> buscar(@PathVariable Integer id) {

        Turno turno = service.buscar(id).orElse(null);

        if(turno != null){
            return ResponseEntity.ok(turno);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

    }

    @PutMapping()
    public ResponseEntity<Turno> actualizar(@RequestBody Turno turno) {
        ResponseEntity<Turno> response = null;

        if (turno.getId() != null && service.buscar(turno.getId()).isPresent())
            response = ResponseEntity.ok(service.guardar(turno));
        else
            response = ResponseEntity.status(HttpStatus.NOT_FOUND).build();

        return response;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable Integer id) {
        ResponseEntity<String> response = null;

        if (service.buscar(id).isPresent()) {
            service.eliminar(id);
            response = ResponseEntity.ok("Eliminado correctamente");
        } else {
            response = ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return response;
    }
}
