package com.example.proyectoBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoBackEndApplication.class, args);
	}

}
