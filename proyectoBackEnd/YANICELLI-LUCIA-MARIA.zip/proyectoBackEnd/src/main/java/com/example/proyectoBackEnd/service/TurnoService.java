package com.example.proyectoBackEnd.service;

import com.example.proyectoBackEnd.model.Turno;
import com.example.proyectoBackEnd.repository.ITurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TurnoService {

    @Autowired
    ITurnoRepository repository;

    public Turno guardar(Turno turno){
        return repository.save(turno);
    }

    public List<Turno> obtenerTodos(){
        return repository.findAll();
    }

    public Optional<Turno> buscar(Integer id){
        return repository.findById(id);
    }

    public void eliminar(Integer id){
        repository.deleteById(id);
    }
}
