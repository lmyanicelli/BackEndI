package com.example.proyectoBackEnd.repository;

import com.example.proyectoBackEnd.model.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ITurnoRepository extends JpaRepository<Turno, Integer> {
}
